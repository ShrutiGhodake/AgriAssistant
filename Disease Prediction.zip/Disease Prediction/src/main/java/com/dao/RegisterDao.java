package com.dao;
import java.util.*;

import javax.swing.JOptionPane;

import com.model.*;
import java.sql.*;
public class RegisterDao {
	Connection con=null;
	MyConnection mcon=new MyConnection();
	PreparedStatement pstate;
	int i;
	public int createRegister(Register rw)
	{
		con=mcon.getConnection();
		try {
			
			
			pstate=con.prepareStatement("insert into AgriAssistant values(?,?,?)");
			
			pstate.setString(1, rw.getUname());
			pstate.setString(2, rw.getEmail());
			
			pstate.setString(3, rw.getPass());
			i=pstate.executeUpdate();
			if(i>0)
			{
				System.out.println("Registration successfull.");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return i;
	}
}