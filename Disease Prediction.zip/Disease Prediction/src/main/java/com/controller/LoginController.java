package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.LoginDao;
import com.model.Login;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    static String uname;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		uname=request.getParameter("username");
		String pass=request.getParameter("password");
		RequestDispatcher dispatcher;
		Login ln=new Login(uname,pass);
		LoginDao dao=new LoginDao();
		boolean b=dao.createLogin(ln);
		PrintWriter pw=response.getWriter();
		if(b)
		{
			response.sendRedirect("profile.html");
		}else {
			dispatcher=request.getRequestDispatcher("login.html");
		}
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
